public class CustomHashSet<E> {
    CustomHashMap<E, Object> map = new CustomHashMap<E, Object>();
    private final static Object PRESENT = new Object();
    public boolean add(E e){
        return map.put(e, PRESENT) == null;
    }
    public boolean remove(E e){
        return map.remove(e) == PRESENT;
    }
    public boolean contains(E o){
        return map.containsKey(o);
    }
    public int size(){
        return map.size();
    }
}
