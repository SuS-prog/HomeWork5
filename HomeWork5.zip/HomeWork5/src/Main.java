public class Main {
    public static void main(String[] args) {
        CustomHashSet<String> hashSet = new CustomHashSet<>();
        hashSet.add("One");
        hashSet.add("Two");
        hashSet.add("Three");
        System.out.println(hashSet.add("Two"));
        System.out.println(hashSet.add("Four"));
        System.out.println(hashSet.contains("Two"));
        System.out.println(hashSet.size());
        System.out.println(hashSet.remove("One"));
        System.out.println(hashSet.size());
    }
}
